package com.ecorhuila.Proyecto_Asistencia.IService;

import com.ecorhuila.Proyecto_Asistencia.Dto.IMateriaUsuarioDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Materia;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface IMateriaService extends IBaseService<Materia>{
    List<IMateriaUsuarioDto> ListMateriaUsuario(String nombre);

}
