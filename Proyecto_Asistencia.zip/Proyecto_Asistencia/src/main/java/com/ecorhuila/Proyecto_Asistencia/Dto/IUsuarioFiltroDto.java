package com.ecorhuila.Proyecto_Asistencia.Dto;

public interface IUsuarioFiltroDto {
    String getUser();
}
