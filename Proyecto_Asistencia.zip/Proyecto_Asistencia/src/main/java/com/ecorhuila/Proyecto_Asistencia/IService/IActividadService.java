package com.ecorhuila.Proyecto_Asistencia.IService;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Actividad;

public interface IActividadService extends IBaseService<Actividad>{

}
