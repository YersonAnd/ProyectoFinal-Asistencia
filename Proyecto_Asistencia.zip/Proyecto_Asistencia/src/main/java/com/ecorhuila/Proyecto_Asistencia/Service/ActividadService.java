package com.ecorhuila.Proyecto_Asistencia.Service;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Actividad;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IActividadRepository;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IBaseRepository;
import com.ecorhuila.Proyecto_Asistencia.IService.IActividadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ActividadService extends BaseService<Actividad> implements IActividadService {
    @Override
    protected IBaseRepository<Actividad, Long> getRepository() {
        return repository;
    }
    @Autowired
    private IActividadRepository repository;
}
