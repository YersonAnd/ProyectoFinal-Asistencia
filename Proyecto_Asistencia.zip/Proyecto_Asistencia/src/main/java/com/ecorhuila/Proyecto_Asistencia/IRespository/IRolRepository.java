package com.ecorhuila.Proyecto_Asistencia.IRespository;


import com.ecorhuila.Proyecto_Asistencia.Enitity.Rol;
import org.springframework.stereotype.Repository;

@Repository
public interface IRolRepository extends IBaseRepository <Rol, Long>{
}
