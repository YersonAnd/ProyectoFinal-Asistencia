package com.ecorhuila.Proyecto_Asistencia.Controller;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Actividad;
import com.ecorhuila.Proyecto_Asistencia.IService.IActividadService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/Actividad")
public class ActividadController extends BaseController<Actividad, IActividadService>  {
    public ActividadController(IActividadService service){super(service, "Actividad");}
}
