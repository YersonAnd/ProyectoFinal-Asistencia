package com.ecorhuila.Proyecto_Asistencia.IService;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Rol;

public interface IRolService extends IBaseService<Rol>{

}
