package com.ecorhuila.Proyecto_Asistencia.Service;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Rol;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IBaseRepository;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IRolRepository;
import com.ecorhuila.Proyecto_Asistencia.IService.IRolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RolService extends BaseService<Rol> implements IRolService {
    @Override
    protected IBaseRepository<Rol, Long> getRepository() {
        return repository;
    }
    @Autowired
    private IRolRepository repository;
}
