package com.ecorhuila.Proyecto_Asistencia.Dto;

public interface IPersonaMateriaDto {
    String getPersona();
    String getMateria();
    String getActividad();
}
