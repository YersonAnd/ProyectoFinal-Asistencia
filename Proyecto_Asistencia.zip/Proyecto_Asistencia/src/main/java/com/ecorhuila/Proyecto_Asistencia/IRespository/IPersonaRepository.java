package com.ecorhuila.Proyecto_Asistencia.IRespository;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Persona;
import org.springframework.stereotype.Repository;

@Repository
public interface IPersonaRepository extends IBaseRepository <Persona, Long>{

}
