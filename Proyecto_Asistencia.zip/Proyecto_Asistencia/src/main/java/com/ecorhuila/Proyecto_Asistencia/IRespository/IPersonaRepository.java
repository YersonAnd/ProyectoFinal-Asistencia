package com.ecorhuila.Proyecto_Asistencia.IRespository;

import com.ecorhuila.Proyecto_Asistencia.Dto.IPersonaMateriaDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Persona;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IPersonaRepository extends IBaseRepository <Persona, Long>{
    @Query(value = "SELECT CONCAT(p.nombre,\" \",p.apellidos) AS persona, m.nombre AS materia, a.nombre AS actividad FROM persona as p\n" +
            "INNER JOIN usuario AS u ON p.id=u.persona_id\n" +
            "INNER JOIN usuario_materia AS um ON u.id=um.user_id\n" +
            "INNER JOIN materia AS m ON um.materia_id=m.id\n" +
            "INNER JOIN actividad AS a ON m.id=a.materia_id", nativeQuery = true)
    List<IPersonaMateriaDto> ListPersonaMateria();

}
