package com.ecorhuila.Proyecto_Asistencia.IService;

import com.ecorhuila.Proyecto_Asistencia.Enitity.UsuarioMateria;

public interface IUsuarioMateriaService extends IBaseService<UsuarioMateria>{
}
