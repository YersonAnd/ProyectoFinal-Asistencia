package com.ecorhuila.Proyecto_Asistencia.Service;

import com.ecorhuila.Proyecto_Asistencia.Dto.IRolUsuarioDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IUsuarioFiltroDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IUsuarioRolDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Usuario;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IBaseRepository;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IUsuarioRepository;
import com.ecorhuila.Proyecto_Asistencia.IService.IUsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService extends BaseService<Usuario> implements IUsuarioService {
    @Override
    protected IBaseRepository<Usuario, Long> getRepository() {
        return repository;
    }
    @Autowired
    private IUsuarioRepository repository;

    @Override
    public List<IUsuarioRolDto> ListUsuarioRol(Boolean estado) {
        return repository.ListUsuarioRol(estado);
    }

    @Override
    public List<IRolUsuarioDto> ListRolUsuario() {
        return repository.ListRolUsuario();
    }

    @Override
    public List<IUsuarioFiltroDto> ListFiltro(String nombre) {
        return repository.ListFiltro(nombre);
    }
}
