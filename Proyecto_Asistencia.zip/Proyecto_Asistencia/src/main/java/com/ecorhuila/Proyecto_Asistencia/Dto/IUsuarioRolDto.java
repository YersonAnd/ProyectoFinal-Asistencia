package com.ecorhuila.Proyecto_Asistencia.Dto;

public interface IUsuarioRolDto {
    String getUsuario();
    String getFuncion();
}
