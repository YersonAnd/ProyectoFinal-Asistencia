package com.ecorhuila.Proyecto_Asistencia.IService;

import com.ecorhuila.Proyecto_Asistencia.Dto.IRolUsuarioDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IUsuarioFiltroDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IUsuarioRolDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Usuario;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface IUsuarioService extends IBaseService<Usuario>{
    List<IUsuarioRolDto> ListUsuarioRol( Boolean estado);

    List<IRolUsuarioDto>ListRolUsuario();
    List<IUsuarioFiltroDto>ListFiltro(String nombre);
}
