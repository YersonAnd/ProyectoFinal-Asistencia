package com.ecorhuila.Proyecto_Asistencia.IService;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Persona;

public interface IPersonaService extends IBaseService<Persona>{
}
