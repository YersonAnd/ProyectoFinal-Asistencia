package com.ecorhuila.Proyecto_Asistencia.IRespository;

import com.ecorhuila.Proyecto_Asistencia.Dto.IMateriaUsuarioDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Materia;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IMateriaRepository extends IBaseRepository <Materia, Long>{
    @Query(value = "SELECT u.usuario,a.nombre AS tarea,a.descripcion FROM usuario AS u \n" +
            "INNER JOIN usuario_materia AS um ON u.id=um.user_id\n" +
            "INNER JOIN materia AS m ON um.materia_id=m.id\n" +
            "INNER JOIN actividad AS a ON m.id=a.materia_id\n" +
            "INNER JOIN rol AS r ON r.usuario_id=u.id\n" +
            "WHERE m.nombre=:nombre AND r.funcion=\"estudiante\"",nativeQuery = true)
    List<IMateriaUsuarioDto>ListMateriaUsuario(@Param("nombre") String nombre);
}
