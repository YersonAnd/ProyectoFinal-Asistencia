package com.ecorhuila.Proyecto_Asistencia.IRespository;

import com.ecorhuila.Proyecto_Asistencia.Dto.IRolUsuarioDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IUsuarioFiltroDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IUsuarioRolDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Usuario;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IUsuarioRepository extends IBaseRepository <Usuario, Long>{
    @Query(value = "SELECT u.usuario, r.funcion FROM usuario AS u\n" +
            "INNER JOIN rol AS r ON u.id=r.usuario_id\n" +
            "WHERE r.state=:estado",nativeQuery = true)
    List<IUsuarioRolDto>ListUsuarioRol(@Param("estado") Boolean estado);


    @Query(value = "SELECT u.usuario,m.nombre AS materia FROM usuario AS u\n" +
            "INNER JOIN usuario_materia AS um ON u.id=um.user_id\n" +
            "INNER JOIN materia AS m ON um.materia_id=m.id\n" +
            "INNER JOIN rol AS r ON u.id=r.usuario_id\n" +
            "WHERE r.funcion=\"estudiante\"",nativeQuery = true)
    List<IRolUsuarioDto>ListRolUsuario();

    @Query(value = "SELECT u.usuario AS user FROM usuario AS u\n" +
            "WHERE u.usuario LIKE %:nombre%",nativeQuery = true)
    List<IUsuarioFiltroDto>ListFiltro(@Param("nombre") String nombre);
}
