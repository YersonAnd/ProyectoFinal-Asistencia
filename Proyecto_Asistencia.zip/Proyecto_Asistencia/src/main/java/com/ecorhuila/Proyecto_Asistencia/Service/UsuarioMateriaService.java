package com.ecorhuila.Proyecto_Asistencia.Service;

import com.ecorhuila.Proyecto_Asistencia.Enitity.UsuarioMateria;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IBaseRepository;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IUsuarioMateriaRepository;
import com.ecorhuila.Proyecto_Asistencia.IService.IUsuarioMateriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsuarioMateriaService extends BaseService<UsuarioMateria> implements IUsuarioMateriaService {
    @Override
    protected IBaseRepository<UsuarioMateria, Long> getRepository() {
        return repository;
    }
    @Autowired
    private IUsuarioMateriaRepository repository;
}
