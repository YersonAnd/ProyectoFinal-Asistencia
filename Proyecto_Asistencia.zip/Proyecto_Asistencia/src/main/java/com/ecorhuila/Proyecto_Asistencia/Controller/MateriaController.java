package com.ecorhuila.Proyecto_Asistencia.Controller;

import com.ecorhuila.Proyecto_Asistencia.Dto.ApiResponseDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IMateriaUsuarioDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IUsuarioRolDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Materia;
import com.ecorhuila.Proyecto_Asistencia.IService.IMateriaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/Materia")
public class MateriaController extends BaseController<Materia, IMateriaService> {
    public MateriaController(IMateriaService service){
        super(service, "Materia");
    }

    @GetMapping("/GetMateria-Usuario-Actividad")
    public ResponseEntity<ApiResponseDto<List<IMateriaUsuarioDto>>> ListMateriaUsuario(@RequestParam String nombre){
        try {
            return ResponseEntity.ok(new ApiResponseDto<List<IMateriaUsuarioDto>>("Datos obtenidos", true, service.ListMateriaUsuario(nombre)));
        }catch (Exception e){
            return ResponseEntity.internalServerError().body(new ApiResponseDto<List<IMateriaUsuarioDto>>(e.getMessage(), false,null));
        }
    }
}
