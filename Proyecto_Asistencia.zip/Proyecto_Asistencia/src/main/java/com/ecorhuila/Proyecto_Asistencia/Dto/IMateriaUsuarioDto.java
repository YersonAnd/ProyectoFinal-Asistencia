package com.ecorhuila.Proyecto_Asistencia.Dto;

public interface IMateriaUsuarioDto {
    String getUsuario();
    String getTarea();
    String getDescripcion();
}
