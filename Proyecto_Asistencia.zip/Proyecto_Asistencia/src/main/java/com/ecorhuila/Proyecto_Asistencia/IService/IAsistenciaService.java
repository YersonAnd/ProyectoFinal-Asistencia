package com.ecorhuila.Proyecto_Asistencia.IService;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Asistencia;

public interface IAsistenciaService extends IBaseService<Asistencia>{
}
