package com.ecorhuila.Proyecto_Asistencia.Service;

import com.ecorhuila.Proyecto_Asistencia.Dto.IMateriaUsuarioDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Materia;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IBaseRepository;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IMateriaRepository;
import com.ecorhuila.Proyecto_Asistencia.IService.IMateriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MateriaService extends BaseService<Materia> implements IMateriaService {
    @Override
    protected IBaseRepository<Materia, Long> getRepository() {
        return repository;
    }
    @Autowired
    private IMateriaRepository repository;

    @Override
    public List<IMateriaUsuarioDto> ListMateriaUsuario(String nombre) {
        return repository.ListMateriaUsuario(nombre);
    }
}
