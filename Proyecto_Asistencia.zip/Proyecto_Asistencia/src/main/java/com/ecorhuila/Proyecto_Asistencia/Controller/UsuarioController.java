package com.ecorhuila.Proyecto_Asistencia.Controller;

import com.ecorhuila.Proyecto_Asistencia.Dto.ApiResponseDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IRolUsuarioDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IUsuarioFiltroDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IUsuarioRolDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Usuario;
import com.ecorhuila.Proyecto_Asistencia.IService.IUsuarioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/Usuario")
public class UsuarioController extends BaseController<Usuario, IUsuarioService>{
    public UsuarioController(IUsuarioService service){
        super(service, "Usuario");
    }

    @GetMapping("/GetUsuarioRol")
    public ResponseEntity<ApiResponseDto<List<IUsuarioRolDto>>> ListUsuarioRol(@RequestParam Boolean estado){
        try {
            return ResponseEntity.ok(new ApiResponseDto<List<IUsuarioRolDto>>("Datos obtenidos", true, service.ListUsuarioRol(estado)));
        }catch (Exception e){
            return ResponseEntity.internalServerError().body(new ApiResponseDto<List<IUsuarioRolDto>>(e.getMessage(), false,null));
        }
    }

    @GetMapping("/GetRolUsuario")
    public ResponseEntity<ApiResponseDto<List<IRolUsuarioDto>>> ListRolUsuario(){
        try {
            return ResponseEntity.ok(new ApiResponseDto<List<IRolUsuarioDto>>("Datos obtenidos", true, service.ListRolUsuario()));
        }catch (Exception e){
            return ResponseEntity.internalServerError().body(new ApiResponseDto<List<IRolUsuarioDto>>(e.getMessage(), false,null));
        }
    }

    @GetMapping("/GetUsuarioFiltro")
    public ResponseEntity<ApiResponseDto<List<IUsuarioFiltroDto>>> ListFiltro(@RequestParam String nombre){
        try {
            return ResponseEntity.ok(new ApiResponseDto<List<IUsuarioFiltroDto>>("Datos obtenidos", true, service.ListFiltro(nombre)));
        }catch (Exception e){
            return ResponseEntity.internalServerError().body(new ApiResponseDto<List<IUsuarioFiltroDto>>(e.getMessage(), false,null));
        }
    }



}
