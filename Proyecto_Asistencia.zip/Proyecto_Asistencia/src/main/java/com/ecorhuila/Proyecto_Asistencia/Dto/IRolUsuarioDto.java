package com.ecorhuila.Proyecto_Asistencia.Dto;

public interface IRolUsuarioDto {
    String getUsuario();
    String getMateria();
}
