package com.ecorhuila.Proyecto_Asistencia.Service;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Asistencia;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IAsistenciaRepository;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IBaseRepository;
import com.ecorhuila.Proyecto_Asistencia.IService.IAsistenciaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AsistenciaService extends BaseService<Asistencia> implements IAsistenciaService {
    @Override
    protected IBaseRepository<Asistencia, Long> getRepository() {
        return repository;
    }
    @Autowired
    private IAsistenciaRepository repository;
}
