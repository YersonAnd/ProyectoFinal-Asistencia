package com.ecorhuila.Proyecto_Asistencia.Controller;

import com.ecorhuila.Proyecto_Asistencia.Dto.ApiResponseDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IPersonaMateriaDto;
import com.ecorhuila.Proyecto_Asistencia.Dto.IRolUsuarioDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Persona;
import com.ecorhuila.Proyecto_Asistencia.IService.IPersonaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/Persona")
public class PersonaController extends BaseController<Persona, IPersonaService> {
    public PersonaController(IPersonaService service){
        super(service, "Persona");
    }

    @GetMapping("/GetPersonaMateria")
    public ResponseEntity<ApiResponseDto<List<IPersonaMateriaDto>>> ListPersonaMateria(){
        try {
            return ResponseEntity.ok(new ApiResponseDto<List<IPersonaMateriaDto>>("Datos obtenidos", true, service.ListPersonaMateria()));
        }catch (Exception e){
            return ResponseEntity.internalServerError().body(new ApiResponseDto<List<IPersonaMateriaDto>>(e.getMessage(), false,null));
        }
    }
}
