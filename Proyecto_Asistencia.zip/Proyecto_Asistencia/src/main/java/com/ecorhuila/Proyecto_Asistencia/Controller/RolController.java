package com.ecorhuila.Proyecto_Asistencia.Controller;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Rol;
import com.ecorhuila.Proyecto_Asistencia.IService.IRolService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/Rol")
public class RolController extends BaseController<Rol, IRolService>{
    public RolController(IRolService service){
        super(service, "Rol");
    }

}
