package com.ecorhuila.Proyecto_Asistencia.Controller;

import com.ecorhuila.Proyecto_Asistencia.Enitity.UsuarioMateria;
import com.ecorhuila.Proyecto_Asistencia.IService.IUsuarioMateriaService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/UsuarioMateria")
public class UsuarioMateriaController extends BaseController<UsuarioMateria, IUsuarioMateriaService> {
    public UsuarioMateriaController(IUsuarioMateriaService service){
        super(service, "UsuarioMateria");
    }

}
