package com.ecorhuila.Proyecto_Asistencia.IRespository;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Asistencia;
import org.springframework.stereotype.Repository;

@Repository
public interface IAsistenciaRepository extends IBaseRepository <Asistencia, Long>{
}
