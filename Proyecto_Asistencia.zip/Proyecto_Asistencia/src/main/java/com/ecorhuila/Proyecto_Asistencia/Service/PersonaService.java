package com.ecorhuila.Proyecto_Asistencia.Service;

import com.ecorhuila.Proyecto_Asistencia.Dto.IPersonaMateriaDto;
import com.ecorhuila.Proyecto_Asistencia.Enitity.Persona;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IBaseRepository;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IPersonaRepository;
import com.ecorhuila.Proyecto_Asistencia.IService.IPersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonaService extends BaseService<Persona> implements IPersonaService {
    @Override
    protected IBaseRepository<Persona, Long> getRepository() {
        return repository;
    }
    @Autowired
    private IPersonaRepository repository;

    @Override
    public List<IPersonaMateriaDto> ListPersonaMateria() {
        return repository.ListPersonaMateria();
    }
}
