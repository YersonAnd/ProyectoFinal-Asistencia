package com.ecorhuila.Proyecto_Asistencia.Service;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Persona;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IBaseRepository;
import com.ecorhuila.Proyecto_Asistencia.IRespository.IPersonaRepository;
import com.ecorhuila.Proyecto_Asistencia.IService.IPersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonaService extends BaseService<Persona> implements IPersonaService {
    @Override
    protected IBaseRepository<Persona, Long> getRepository() {
        return repository;
    }
    @Autowired
    private IPersonaRepository repository;
}
