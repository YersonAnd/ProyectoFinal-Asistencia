package com.ecorhuila.Proyecto_Asistencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoAsistenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoAsistenciaApplication.class, args);
	}

}
