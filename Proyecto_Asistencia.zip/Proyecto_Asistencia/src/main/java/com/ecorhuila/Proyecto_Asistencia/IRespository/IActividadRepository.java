package com.ecorhuila.Proyecto_Asistencia.IRespository;

import com.ecorhuila.Proyecto_Asistencia.Enitity.Actividad;
import org.springframework.stereotype.Repository;

@Repository
public interface IActividadRepository extends IBaseRepository <Actividad, Long>{
}
