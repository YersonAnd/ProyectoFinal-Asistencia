package com.ecorhuila.Proyecto_Asistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoAsistenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
